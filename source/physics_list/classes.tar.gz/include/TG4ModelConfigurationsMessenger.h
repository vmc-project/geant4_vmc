#ifndef TG4_MODEL_CONFIGURATIONS_MESSENGER_H
#define TG4_MODEL_CONFIGURATIONS_MESSENGER_H 

//------------------------------------------------
// The Geant4 Virtual Monte Carlo package
// Copyright (C) 2007 - 2015 Ivana Hrivnacova
// All rights reserved.
//
// For the licensing terms see geant4_vmc/LICENSE.
// Contact: root-vmc@cern.ch
//-------------------------------------------------

/// \file TG4ModelConfigurationsMessenger.h
/// \brief Definition of the TG4ModelConfigurationsMessenger class 
///
/// \author I. Hrivnacova; IPN Orsay

#include <G4UImessenger.hh>
#include <globals.hh>

class TG4ModelConfigurations;

class G4UIdirectory;
class G4UIcmdWithAString;

/// \ingroup physics_list
/// \brief Messenger class that defines commands for the fast simulation models
///
/// Implements commands:
/// - /mcPhysics/physicsName/setModel modelName
/// - /mcPhysics/physicsName/setParticles particleName1 particleName2 ...
/// - /mcPhysics/physicsName/setRegions regionName1 regionName2 ...
/// where physicName = fastSimulationPhysics.
///
/// The messenger is intended to substitute TG4EmModelPhysicsMessenger.
///
/// \author I. Hrivnacova; IPN Orsay

class TG4ModelConfigurationsMessenger: public G4UImessenger
{
  public:
    TG4ModelConfigurationsMessenger(TG4ModelConfigurations* modelConfigurations,
                                    const G4String& availableModels);
    virtual ~TG4ModelConfigurationsMessenger();
   
    // methods 
    virtual void SetNewValue(G4UIcommand* command, G4String string);
    
  private:
    /// Not implemented
    TG4ModelConfigurationsMessenger();  
    /// Not implemented
    TG4ModelConfigurationsMessenger(const TG4ModelConfigurationsMessenger& right);
    /// Not implemented
    TG4ModelConfigurationsMessenger& operator=(const TG4ModelConfigurationsMessenger& right);

    //
    // data members
    
    /// associated class
    TG4ModelConfigurations*  fModelConfigurations;
    
    /// current model name
    G4String               fSelectedModel;

    /// command directory
    G4UIdirectory*         fDirectory; 

    /// setElossModel command
    G4UIcmdWithAString*    fSetModelCmd;

    /// setParticles command
    G4UIcmdWithAString*    fSetParticlesCmd;

    /// setRegions command
    G4UIcmdWithAString*    fSetRegionsCmd;
};    

#endif //TG4_MODEL_CONFIGURATIONS_MESSENGER_H
