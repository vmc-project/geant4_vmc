//------------------------------------------------
// The Geant4 Virtual Monte Carlo package
// Copyright (C) 2007 - 2015 Ivana Hrivnacova
// All rights reserved.
//
// For the licensing terms see geant4_vmc/LICENSE.
// Contact: root-vmc@cern.ch
//-------------------------------------------------

/// \file TG4ModelConfiguration.cxx
/// \brief Implementation of the TG4ModelConfiguration class 
///
/// \author I. Hrivnacova; IPN, Orsay

#include "TG4ModelConfiguration.h"

//_____________________________________________________________________________
TG4ModelConfiguration::TG4ModelConfiguration(const G4String& modelName)
  : fModelName(modelName),
    fParticles(),
    fRegions(),
    fFastSimulationModel(0)
{
/// Standard constructor

  G4cout << "TG4ModelConfiguration::TG4ModelConfiguration " << modelName  << G4endl;
}

/*
//_____________________________________________________________________________
TG4ModelConfiguration::TG4ModelConfiguration(const TG4Model& rhs)
  : fModelName(rhs.fModelName),
    fParticles(rhs.fParticles),
    fRegions(rhs.fRegions),
    fFastSimulationModel(rhs.fFastSimulationModel)
{
/// Copy constructor

  G4cout << "TG4ModelConfiguration::TG4ModelConfiguration(rhs)" << G4endl;
}

//_____________________________________________________________________________
TG4ModelConfiguration& 
TG4ModelConfiguration::operator=(const TG4ModelConfiguration& rhs)
{
/// Assignment operator
 
  // check assignment to self
  if (this == &rhs) return *this;

  // assignment operator
  //fModelType = rhs.fModelType;
  fModelName = rhs.fModelName;
  fParticles = rhs.fParticles;
  fRegions = rhs.fRegions;
  fFastSimulationModel = rhs.fFastSimulationModel;

  return *this;
}
*/

//_____________________________________________________________________________
TG4ModelConfiguration::~TG4ModelConfiguration() 
{
/// Destructor
}
