//------------------------------------------------
// The Geant4 Virtual Monte Carlo package
// Copyright (C) 2007 - 2015 Ivana Hrivnacova
// All rights reserved.
//
// For the licensing terms see geant4_vmc/LICENSE.
// Contact: root-vmc@cern.ch
//-------------------------------------------------

/// \file TG4ModelConfigurations.cxx
/// \brief Implementation of the TG4ModelConfigurations class 
///
/// \author I. Hrivnacova; IPN, Orsay

#include "TG4ModelConfigurations.h"
#include "TG4ModelConfigurationsMessenger.h"
#include "TG4ModelConfiguration.h"
#include "TG4PhysicsManager.h"
#include "TG4GeometryServices.h"
#include "TG4MediumMap.h"
#include "TG4Medium.h"
#include "TG4Limits.h"
#include "TG4G3ControlVector.h"

#include <G4TransportationManager.hh>
#include <G4LogicalVolumeStore.hh>
#include <G4LogicalVolume.hh>
#include <G4RegionStore.hh>
#include <G4Region.hh>
#include <G4ProductionCuts.hh>
#include <G4Material.hh>

//_____________________________________________________________________________
TG4ModelConfigurations::TG4ModelConfigurations(const G4String& name,
                                               const G4String& availableModels)
  : fMessenger(0),
    fName(name),
    fAvailableModels(availableModels),
    fVector()
{
/// Standard constructor

  fMessenger = new TG4ModelConfigurationsMessenger(this, availableModels);
}

//_____________________________________________________________________________
TG4ModelConfigurations::~TG4ModelConfigurations() 
{
/// Destructor

  delete fMessenger;

  ModelConfigurationVector::iterator it;
  for ( it = fVector.begin(); it != fVector.end(); it++ ) {
    delete *it;
  }
}

//
// public methods
//

//_____________________________________________________________________________
void TG4ModelConfigurations::CreateRegions() const
{
/// Create regions for all registered models
  
  // G4cout << "TG4ModelConfigurations::ConstructRegions" << G4endl;

  // Get world default region 
  G4LogicalVolume* worldLV 
    = G4TransportationManager::GetTransportationManager()
        ->GetNavigatorForTracking()->GetWorldVolume()->GetLogicalVolume();
        // We cannot access world volume via geometry services as 
        // the it is available here only after initialization

  // Get default range cut values from physics manager
  G4double rangeCutGam 
    = TG4PhysicsManager::Instance()->GetCutForGamma();
  G4double rangeCutEle 
    = TG4PhysicsManager::Instance()->GetCutForElectron();
  G4double rangeCutPos 
    = TG4PhysicsManager::Instance()->GetCutForPositron();

  // Loop over logical volumes
  G4LogicalVolumeStore* lvStore = G4LogicalVolumeStore::GetInstance();
  for (G4int i=0; i<G4int(lvStore->size()); i++) {
    G4LogicalVolume* lv = (*lvStore)[i];
    G4bool isWorld = ( lv == worldLV ) ;
    
    if ( isWorld ) continue;

    TG4Medium* medium
      = TG4GeometryServices::Instance()->GetMediumMap()->GetMedium(lv, false);

    if ( ! medium ) continue;

    G4String mediumName = medium->GetName();
    G4String materialName = lv->GetMaterial()->GetName();

    //G4cout << "Processing volume " << lv->GetName()
    //      << ", medium " << mediumName
    //      << ", material " << materialName << G4endl;

    // Skip volumes with media which are not in the map  
    G4bool isModelRegion = false;
    ModelConfigurationVector::const_iterator it;
    for ( it = fVector.begin(); it != fVector.end(); it++ ) {
      G4String regions = (*it)->GetRegions();
      if ( regions.find(mediumName) != std::string::npos ) isModelRegion = true;
    }

    if ( ! isModelRegion ) continue;

    // If region already exists, only add the logical volume
    // and continue the loop   
    G4Region* region 
      = G4RegionStore::GetInstance()->GetRegion(materialName, false );
    //G4cout << "Got region " << regionName << " " << region << G4endl;
    
    if ( ! region ) {
      region = new G4Region(materialName);
      G4ProductionCuts* dcuts = new G4ProductionCuts();
      dcuts->SetProductionCut(rangeCutGam, 0);
      dcuts->SetProductionCut(rangeCutEle, 1);
      dcuts->SetProductionCut(rangeCutPos, 2);
      region->SetProductionCuts(dcuts);
      //G4cout << "Created region " << regionName << G4endl;
    }   
    
    region->AddRootLogicalVolume(lv);
  }  
}    

//_____________________________________________________________________________
void TG4ModelConfigurations::SetModel(const G4String& modelName)
{
/// Set an extra EM model with the given name.

  G4cout << "TG4ModelConfigurations::SetModel " << modelName << G4endl;

  if ( ! GetModelConfiguration(modelName, false) ) {
    fVector.push_back(new TG4ModelConfiguration(modelName));
  }
  else {
    TString text = "Cannot create model ";
    text +=  modelName.data();
    text += " twice.";
    TG4Globals::Warning(
      "TG4ModelConfigurations", "SetModel", text);
  }
}

//_____________________________________________________________________________
void TG4ModelConfigurations::SetModelParticles(const G4String& modelName,
                                       const G4String& particles)
{
/// Set particles for the physics model for given medium.

  TG4ModelConfiguration* modelConfiguration
    = GetModelConfiguration(modelName, "SetModelParticles");

  if ( ! modelConfiguration ) return;

  modelConfiguration->SetParticles(particles);
}

//_____________________________________________________________________________
void TG4ModelConfigurations::SetModelRegions(const G4String& modelName,
                                     const G4String& regions)
{
/// Set regions for the physics model for given medium.

  TG4ModelConfiguration* modelConfiguration
    = GetModelConfiguration(modelName, "SetModelRegions");

  if ( ! modelConfiguration ) return;

  modelConfiguration->SetRegions(regions);
}

//_____________________________________________________________________________
TG4ModelConfiguration* 
TG4ModelConfigurations::GetModelConfiguration(const G4String& modelName, 
                                              G4bool warn) const
{
/// Return the model configuration via specified model name;
/// print warning if a configuration is not found

  ModelConfigurationVector::const_iterator it;
  for ( it = fVector.begin(); it != fVector.end(); it++ ) {
    if ( (*it)->GetModelName() == modelName ) return *it;
  }

  if ( warn ) {
    TString text = "Model configuration ";
    text +=  modelName.data();
    text += " does not exist";
    TG4Globals::Warning(
      "TG4ModelConfigurations", "GetModelConfiguration", text);
  }

  return 0;
}


