//------------------------------------------------
// The Geant4 Virtual Monte Carlo package
// Copyright (C) 2007 - 2014 Ivana Hrivnacova
// All rights reserved.
//
// For the licensing terms see geant4_vmc/LICENSE.
// Contact: root-vmc@cern.ch
//-------------------------------------------------

/// \file TG4VUserFastSimulation.cxx
/// \brief Implementation of the TG4VUserFastSimulation class
///
/// \author I. Hrivnacova; IPN, Orsay

#include "TG4VUserFastSimulation.h"
#include "TG4ModelConfigurations.h"
#include "TG4ModelConfiguration.h"
#include "TG4Globals.h"

#include <G4VFastSimulationModel.hh>

//_____________________________________________________________________________
TG4VUserFastSimulation::TG4VUserFastSimulation()
 : fModelNames(),
   fModelConfigurations(0)
{
/// Default constructor
}

//_____________________________________________________________________________
TG4VUserFastSimulation::~TG4VUserFastSimulation() 
{
/// Destructor
}

//
// protected methods
//

//_____________________________________________________________________________
void TG4VUserFastSimulation::SetModel(const G4String& modelName)
{
  if ( fModelNames.size() ) {
  	fModelNames.append(" ");
  }

  fModelNames.append(modelName);	
}

//_____________________________________________________________________________
void TG4VUserFastSimulation::SetModelParticles(const G4String& modelName,
                                               const G4String& particles)
{
  if ( ! fModelConfigurations) {
  	// add exception
  	return;
  }

  fModelConfigurations->SetModelParticles(modelName, particles);
}

//_____________________________________________________________________________
void TG4VUserFastSimulation::SetModelRegions(const G4String& modelName,
                                             const G4String& regions)
{
  if ( ! fModelConfigurations) {
  	// add exception
  	return;
  }

  fModelConfigurations->SetModelRegions(modelName, regions);
}

//_____________________________________________________________________________
void TG4VUserFastSimulation::Register(G4VFastSimulationModel* fastSimulationModel)
{
/// Register the user fast simulation model

  // check that model configuration exists
  TG4ModelConfiguration* modelConfiguration
    = fModelConfigurations->GetModelConfiguration(fastSimulationModel->GetName());
  if ( ! modelConfiguration ) {
  	// add warnings
  	return;
  }
  
  modelConfiguration->SetFastSimulationModel(fastSimulationModel);
}



