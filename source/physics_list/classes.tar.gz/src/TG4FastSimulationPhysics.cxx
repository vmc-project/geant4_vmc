//------------------------------------------------
// The Geant4 Virtual Monte Carlo package
// Copyright (C) 2007 - 2015 Ivana Hrivnacova
// All rights reserved.
//
// For the licensing terms see geant4_vmc/LICENSE.
// Contact: root-vmc@cern.ch
//-------------------------------------------------

/// \file TG4FastSimulationPhysics.cxx
/// \brief Implementation of the TG4FastSimulationPhysics class 
///
/// \author I. Hrivnacova; IPN, Orsay

#include "TG4FastSimulationPhysics.h"
#include "TG4VUserFastSimulation.h"
#include "TG4GeometryServices.h"
#include "TG4ModelConfiguration.h"
#include "TG4ModelConfigurations.h"
// #include "TG4PhysicsManager.h"
// #include "TG4GeometryServices.h"
// #include "TG4MediumMap.h"
// #include "TG4Medium.h"
// #include "TG4Limits.h"
// #include "TG4G3ControlVector.h"
#include "TG4Globals.h"

#include <G4ParticleDefinition.hh>
#include <G4ProcessManager.hh>
#include <G4FastSimulationManagerProcess.hh>
#include <G4RegionStore.hh>
#include <G4Region.hh>
#include <G4AnalysisUtilities.hh>

//_____________________________________________________________________________
G4ThreadLocal 
TG4FastSimulationPhysics::ProcessMap* TG4FastSimulationPhysics::fgProcessMap = 0;

//_____________________________________________________________________________
TG4FastSimulationPhysics::TG4FastSimulationPhysics(const G4String& name)
  : TG4VPhysicsConstructor(name),
    fUserFastSimulation(0),
    fModelConfigurations(name)
{
/// Standard constructor
}

//_____________________________________________________________________________
TG4FastSimulationPhysics::TG4FastSimulationPhysics(G4int theVerboseLevel,
                                                   const G4String& name)
  : TG4VPhysicsConstructor(name, theVerboseLevel),
    fUserFastSimulation(0),
    fModelConfigurations(name)
{
/// Standard constructor
}

//_____________________________________________________________________________
TG4FastSimulationPhysics::~TG4FastSimulationPhysics() 
{
/// Destructor

  if ( fgProcessMap ) {
    ProcessMap::iterator it;
    for ( it=fgProcessMap->begin(); it != fgProcessMap->end(); it++) {
      delete it->second;
    }
    delete fgProcessMap;
    fgProcessMap = 0;
  }
}

//
// private methods
//

//_____________________________________________________________________________
G4FastSimulationManagerProcess* 
TG4FastSimulationPhysics::GetOrCreateFastSimulationProcess(const G4String& modelName)
{
/// Get thread-local fast simulation process (and create one if it does
/// not yet exist)  

  // Create fast simulation process map if it does not yet exist
  if ( ! fgProcessMap ) {
    fgProcessMap = new ProcessMap();
  }

  // Create one thread-local fast simulation process per model
  G4FastSimulationManagerProcess*  fastSimulationProcess = 0; 
  ProcessMap::iterator it 
    = fgProcessMap->find(modelName);
  if ( it != fgProcessMap->end() ) {
    fastSimulationProcess = it->second;
  } else {
    fastSimulationProcess = new G4FastSimulationManagerProcess(modelName);
    (*fgProcessMap)[modelName] = fastSimulationProcess;
  }

  return fastSimulationProcess;
}

//_____________________________________________________________________________
void TG4FastSimulationPhysics::AddFastSimulationProcess()
{
/// Loop over all particles and their processes and check if
/// the process is present in the map

  if ( VerboseLevel() > 1 ) {
    G4cout << "TG4FastSimulationPhysics::AddFastSimulationProcess" << G4endl;
  }  

  const std::vector<TG4ModelConfiguration*>& models = fModelConfigurations.GetVector();

  std::vector<TG4ModelConfiguration*>::const_iterator it;
  for ( it = models.begin(); it != models.end(); it++ ) {

    // Get model configuration
    // TG4EmModel emModel = GetEmModel((*it)->GetModelName());
    G4String modelName = (*it)->GetModelName();
    G4String particles = (*it)->GetParticles();
    
    G4FastSimulationManagerProcess* fastSimulationProcess 
      = GetOrCreateFastSimulationProcess(modelName);
 
    // Add selected models
    aParticleIterator->reset();
    while ((*aParticleIterator)()) {
      G4ParticleDefinition* particle = aParticleIterator->value();
      G4String particleName = particle->GetParticleName();
      
      // skip particles which are not in selection
      if ( particles != "all" &&
           particles.find(particle->GetParticleName()) == std::string::npos ) {
           continue;
      }     
      
      G4cout << "Adding model " << modelName 
             << " to particle " <<  particle->GetParticleName() << G4endl;       

      // Set the process to the particle process manager           
      // particle->GetProcessManager()->AddDiscreteProcess(fastSimulationProcess);
      particle->GetProcessManager()->AddProcess(fastSimulationProcess, -1, 0, 0);
      //particle->GetProcessManager()->AddProcess(fastSimulationProcess);
      //particle->GetProcessManager()->SetProcessOrdering(fastSimulationProcess,idxPostStep);

    }
  }
}

//_____________________________________________________________________________
void TG4FastSimulationPhysics::UpdateRegions()
{

  if ( VerboseLevel() > 1 ) {
    G4cout << "TG4FastSimulationPhysics::UpdateRegions" << G4endl;
  }        
  
  const std::vector<TG4ModelConfiguration*>& models = fModelConfigurations.GetVector();

  std::vector<TG4ModelConfiguration*>::const_iterator it;
  for ( it = models.begin(); it != models.end(); it++ ) {

    // Get model configuration
    G4String modelName = (*it)->GetModelName();
    G4String regions = (*it)->GetRegions();
    G4VFastSimulationModel* fastSimulationModel = (*it)->GetFastSimulationModel();

    if ( ! regions.size() ) {
      // add exception
      continue;
    }

    std::vector<G4String> regionVector;
    // use analysis utility to tokenize regions
    G4Analysis::Tokenize(regions, regionVector);

    for (G4int j=0; j<G4int(regionVector.size()); ++j) {
  
      // Get region
      G4Region* region 
        = G4RegionStore::GetInstance()->GetRegion(regionVector[j]);
  
      if ( ! region ) {
        // change to exception
        G4cerr << "Region " << regionVector[j] << " not found." << G4endl;
      }
  
      // Retrieve fast simulation manager ou create one if needed.
      G4FastSimulationManager* fastSimulationManager
        = region->GetFastSimulationManager();
      if ( ! fastSimulationManager ) {
        // TO DO: CHECK THIS
        G4bool isUnique = false; 
        fastSimulationManager = new G4FastSimulationManager(region, isUnique);
        fastSimulationManager->AddFastSimulationModel(fastSimulationModel);
      }
    }
  }
}

//
// protected methods
//

//_____________________________________________________________________________
void TG4FastSimulationPhysics::ConstructParticle()
{
/// Instantiate particles - nothing to be done here
}

//_____________________________________________________________________________
void TG4FastSimulationPhysics::ConstructProcess()
{
  if ( VerboseLevel() > 1 ) {
    G4cout << "TG4FastSimulationPhysics::ConstructProcess " << G4endl;
  }

  // Do nothing if no models were set  
  if ( fModelConfigurations.GetVector().size() == 0 ) {
    if ( VerboseLevel() > 1 ) {
      G4cout << "No fast simulation models are defined." << G4endl;
    }
    return;
  }

  // Configure user models
  if ( fUserFastSimulation ) {
    fUserFastSimulation->Configure();
  }

  // Create regions
  fModelConfigurations.CreateRegions();

  // Construct user models
  if ( fUserFastSimulation ) {
    fUserFastSimulation->Construct();
  }

  // Add fast simulation process to particles
  AddFastSimulationProcess();
  
  // Update regions
  UpdateRegions();

  if ( VerboseLevel() > 0 ) {
    G4cout << "### Fast simulation models added to physics processes" << G4endl;
  }

  // For test
  // Check region
  G4Region* region = G4RegionStore::GetInstance()->GetRegion("PbWO4");
  if ( region ) {
    G4cout << "PbWO4 fast manager: " << region->GetFastSimulationManager() << G4endl;
  } else {
    G4cout << "PbWO4 region not found." << G4endl;
  }
}


//
// public methods
//

//_____________________________________________________________________________
void TG4FastSimulationPhysics::SetUserFastSimulation(TG4VUserFastSimulation* fastSimulation) 
{ 
/// Set user fast simulation class
/// and process the list of models defines by the user, create the model configuration
/// objects for these models and pass them back in the user class.

  fUserFastSimulation = fastSimulation; 

  // process user the list of defined models and save them in this class data
  G4String modelNames = fUserFastSimulation->fModelNames;
  if ( ! modelNames.size() ) {
    // add exception
    return;
  }

  // use analysis utility to tokenize the list of models
  std::vector<G4String> modelNamesVector;
  G4Analysis::Tokenize(modelNames, modelNamesVector);
  for (G4int i=0; i<G4int(modelNamesVector.size()); ++i) {
    fModelConfigurations.SetModel(modelNamesVector[i]);
  }

  // pass the configured vector to user class
  fastSimulation->fModelConfigurations = &fModelConfigurations;
}
